# PyCoupling

This is a python package used for calulating cable coupling and cross talk.

